
from keras.models import Model, Sequential
from keras.layers import Dense, Activation, Flatten, Input, Dropout, MaxPooling1D, Convolution1D
from keras.layers import LSTM, Lambda, merge, Masking, SimpleRNN, GRU
from keras.layers import Embedding, TimeDistributed, Bidirectional
from keras import backend as K
import keras.callbacks
import numpy as np
from keras.utils import np_utils
import sys, os
from keras.callbacks import ModelCheckpoint
from keras.callbacks import EarlyStopping 
import gensim
#from tqdm import tqdm
from sklearn.model_selection import train_test_split
import numpy as np
from collections import namedtuple

def label_to_int(label):
	labels={'SOCL':0,'PREG':1,'GOAL':2,'TRMT':3,'DEMO':4,'FAML':5,'DISE':6}
	return labels[label]
'''
def lab(filename):
    with open(filename) as f:
        for uid, line in tqdm(enumerate(f)):
            if(len(line) == 0): continue
            line = line.split('\t')
            yield gensim.models.doc2vec.TaggedDocument(line[2].split(), ([line[0] + '%s' % uid]))
    f.close()
'''
nb_epochs = 20
from gensim.models.doc2vec import Doc2Vec
	#x_train = list(lab('/home/rama/Desktop/20162029/sem3/IRE/project2/src/group27/input-data-merged.txt'))
fp = open('./input-data-merged.txt','r')
lines = fp.readlines()
	#model = Doc2Vec(x_train, size=100, min_count=1)
	#model.build_vocab(x_train)
	#import time
	#t0 = time.time()
	#model.train(x_train, total_examples=len(x_train), epochs=model.iter)



	#model.save('./vectors.d2v')

	#model = Doc2Vec.load('./vectors.d2v')
	#print(time.time() - t0, "seconds")

	#print(model.most_similar('week'))
	#print(model['pain'])
X_raw=[]
y_raw=[]
i = 0;
for line in lines:
	data = line.split('\t\t')
	X = data[1]
	y = label_to_int(data[0])
	X_raw.append(X)
	y_raw.append(y)  

docs = []
analyzedDocument = namedtuple('AnalyzedDocument', 'words tags')
for i, text in enumerate(X_raw):
	words = text.lower().split()
	tags = [i]
	docs.append(analyzedDocument(words, tags))


#Y_train,Y_test=Y[:9000],Y[9000:] 

from keras.utils import np_utils

y_raw = np_utils.to_categorical(y_raw)

from gensim.models import doc2vec

model = doc2vec.Doc2Vec(docs,size=300, window=10, min_count=5, workers=11,alpha=0.025, min_alpha=0.025) # use fixed learning rate

x_raw=[]
for i in range(len(X_raw)):
	x_raw.append(model.docvecs[i])
	
x_raw = np.array(x_raw)
y_raw = np.array(y_raw)
print x_raw.shape
print y_raw.shape


X_train, X_test, y_train, y_test = train_test_split(x_raw, y_raw, test_size=0.20, random_state=42)


X_train=np.reshape(X_train,(X_train.shape[0],X_train.shape[1],1))
X_test=np.reshape(X_test,(X_test.shape[0],X_test.shape[1],1))
nb_classes = 7
# y_train = np_utils.to_categorical(y_train, nb_classes)
# y_test = np_utils.to_categorical(y_test, nb_classes)
	


# model = Sequential()
# model.add(LSTM(128, input_shape =(X_train.shape[1],X_train.shape[2])))
# model.add(Activation('relu'))
# model.add(Dense(64, init='uniform'))
# model.add(Activation('relu'))
# model.add(Dropout(0.5))
# model.add(Dense(7))
# model.add(Activation('softmax'))
# model.compile(loss='categorical_crossentropy', optimizer='adam',metrics=['accuracy'])
# model.fit(X_train, y_train, nb_epoch=nb_epochs,batch_size=50,verbose=1, validation_data=(X_test, y_test))
# scores = model.evaluate(X_test, y_test, verbose=0)
# print('LSTM test score:', scores[0])
# print('LSTM test accuracy:', scores[1])


model = Sequential()
model.add(Embedding(5000, 100, input_length=300))
model.add(LSTM(100, dropout=0.2, recurrent_dropout=0.2))
model.add(Dense(7, activation='softmax'))
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
print(model.summary())
model.fit(X_train, y_train, epochs=10, batch_size=64)
# Final evaluation of the model
scores = model.evaluate(X_test, y_test, verbose=0)
print("Accuracy: %.2f%%" % (scores[1]*100))

# def generate_features(sentence):
# 	#print(url,aa,bc)
# 	vec = libspacy3.get_vector(sentence)
# 	return vec.tolist()  

# if __name__=="__main__":
# 	main()
